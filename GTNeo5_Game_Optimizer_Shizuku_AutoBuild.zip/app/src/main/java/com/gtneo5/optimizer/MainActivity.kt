package com.gtneo5.optimizer

import android.app.Activity
import android.os.Bundle
import android.content.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 24, 32)
    private val panel = Color.rgb(28, 40, 50)
    private val accent = Color.rgb(22, 160, 133)
    private val prefs by lazy { getSharedPreferences("optimizer", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var temp: TextView
    private lateinit var output: TextView
    private lateinit var root: LinearLayout

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == 1001) {
            refreshShizuku()
            toast(if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED)
                "Разрешение Shizuku выдано" else "Разрешение Shizuku не выдано")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildUi()
        refreshShizuku()
        updateBatteryTemp()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply { setColor(panel); cornerRadius = dp(16).toFloat() }
        val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(12); layoutParams = p
    }

    private fun label(s: String, size: Float = 15f, color: Int = Color.WHITE) =
        TextView(this).apply { text = s; textSize = size; setTextColor(color) }

    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
        setOnClickListener { action() }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
        }
        scroll.addView(root); setContentView(scroll)

        root.addView(label("REALME GT NEO 5", 13f, accent))
        root.addView(label("GAME OPTIMIZER", 27f).apply {
            setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, dp(4))
        })
        root.addView(label("Fortnite • Balanced / Cool • No Root", 14f, 0xFFB7C4CC.toInt())
            .apply { setPadding(0, 0, 0, dp(18)) })

        val sh = card()
        sh.addView(label("SHIZUKU", 17f).apply { setTypeface(null, Typeface.BOLD) })
        status = label("Проверка подключения…", 13f, 0xFFB7C4CC.toInt())
        sh.addView(status)
        sh.addView(button("Проверить Shizuku") { refreshShizuku() })
        sh.addView(button("Выдать разрешение Shizuku") { requestShizukuPermission() })
        root.addView(sh)

        val profile = card()
        profile.addView(label("ПРОФИЛИ ИГРЫ", 17f).apply { setTypeface(null, Typeface.BOLD) })
        profile.addView(label(
            "BALANCED: рекомендуемый старт — Fortnite 60 FPS, низкие/средние эффекты, яркость по ситуации.\n\n" +
            "COOL: если корпус быстро нагревается — 30/40 FPS (если доступно), снизить яркость и сделать перерыв.\n\n" +
            "Эти игровые параметры выбираются внутри Fortnite. Приложение не меняет частоты CPU/GPU и не отключает термозащиту.",
            14f, 0xFFE0E7EB.toInt()
        ).apply { setPadding(0, dp(8), 0, dp(8)) })
        profile.addView(button("Открыть Fortnite") { launchFortnite() })
        root.addView(profile)

        val thermal = card()
        thermal.addView(label("ТЕМПЕРАТУРА", 17f).apply { setTypeface(null, Typeface.BOLD) })
        temp = label("Батарея: -- °C", 22f)
        thermal.addView(temp)
        thermal.addView(button("Обновить температуру батареи") { updateBatteryTemp() })
        thermal.addView(button("Прочитать тепловые датчики через Shizuku") { readThermalService() })
        output = label("Данные thermalservice появятся здесь, если прошивка их предоставляет.", 12f, 0xFFB7C4CC.toInt())
        output.setPadding(0, dp(8), 0, 0)
        thermal.addView(output)
        root.addView(thermal)

        val display = card()
        display.addView(label("ЧАСТОТА ЭКРАНА", 17f).apply { setTypeface(null, Typeface.BOLD) })
        display.addView(label(
            "Не меняем частоту автоматически: у китайской Realme UI названия и поведение системных ключей могут отличаться. Используй системные настройки дисплея и выбери 60 Гц, если хочешь снизить расход и нагрев.",
            13f, 0xFFB7C4CC.toInt()
        ))
        display.addView(button("Открыть настройки дисплея") {
            try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        })
        root.addView(display)

        val note = card()
        note.addView(label("ВАЖНО", 14f, accent).apply { setTypeface(null, Typeface.BOLD) })
        note.addView(label(
            "Shizuku запускается отдельно: включи его через беспроводную отладку или ADB после каждой перезагрузки (если требуется). Не выдавай разрешения неизвестным приложениям. Чтение thermalservice — диагностическая функция; вывод датчиков зависит от прошивки.",
            12f, 0xFFB7C4CC.toInt()
        ))
        root.addView(note)
    }

    private fun refreshShizuku() {
        val alive = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        if (!alive) {
            status.text = "Shizuku не запущен. Запусти Shizuku и повтори проверку."
            return
        }
        val granted = try { Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED }
            catch (_: Exception) { false }
        status.text = if (granted) "Подключено • разрешение выдано" else "Shizuku запущен • нужно выдать разрешение"
    }

    private fun requestShizukuPermission() {
        if (!Shizuku.pingBinder()) {
            toast("Сначала запусти Shizuku")
            return
        }
        try {
            if (Shizuku.isPreV11()) {
                toast("Обнови Shizuku до актуальной версии")
                return
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast("Разрешение уже выдано")
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (_: Exception) {
            toast("Не удалось запросить разрешение. Проверь версию Shizuku.")
        }
    }

    private fun updateBatteryTemp() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = intent?.getIntExtra("temperature", -1) ?: -1
        temp.text = if (raw > 0) {
            val c = raw / 10.0
            val advice = when {
                c >= 42 -> " • высокая температура — останови игру и дай телефону остыть"
                c >= 38 -> " • нагрев заметен — снизь FPS/яркость"
                else -> " • температура батареи"
            }
            String.format("Батарея: %.1f °C%s", c, advice)
        } else "Батарея: нет данных"
    }

    private fun readThermalService() {
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            toast("Сначала запусти Shizuku и выдай разрешение")
            return
        }
        output.text = "Читаю системные тепловые датчики…"
        thread {
            val result = runShell("dumpsys thermalservice")
            runOnUiThread {
                output.text = if (result.isBlank()) "Прошивка не вернула данные thermalservice."
                else result.take(3500)
            }
        }
    }

    private fun runShell(command: String): String {
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val text = reader.readText()
            process.waitFor()
            text
        } catch (e: Exception) {
            "Ошибка чтения: ${e.message ?: "неизвестная ошибка"}"
        }
    }

    private fun launchFortnite() {
        val ids = listOf("com.epicgames.fortnite", "com.epicgames.portal")
        for (id in ids) {
            packageManager.getLaunchIntentForPackage(id)?.let { startActivity(it); return }
        }
        toast("Fortnite не найден. Открой игру вручную.")
    }
}
