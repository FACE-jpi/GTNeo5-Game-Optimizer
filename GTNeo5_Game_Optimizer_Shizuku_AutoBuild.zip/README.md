# GT Neo 5 Game Optimizer — APK + Shizuku

Проект Android Studio для Realme GT Neo 5 с китайской Realme UI, без Root.

## Сборка APK
1. Установи Android Studio и Android SDK Platform 35.
2. Открой папку проекта в Android Studio.
3. Дождись Gradle Sync (нужен интернет для загрузки Android Gradle Plugin и Shizuku API).
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Настройка телефона
1. Установи Shizuku из официального источника: https://shizuku.rikka.app/
2. Включи параметры разработчика и беспроводную отладку.
3. Запусти Shizuku способом Wireless debugging, сопряги pairing code.
4. Установи собранный APK.
5. Открой оптимизатор → «Выдать разрешение Shizuku».

## Что умеет эта версия
- Проверять, запущен ли Shizuku, и запрашивать его разрешение.
- Читать `dumpsys thermalservice` для диагностики доступных тепловых датчиков.
- Показывать температуру аккумулятора из Android Battery Intent.
- Давать практический Balanced/Cool профиль для Fortnite.
- Открывать системные настройки дисплея и запускать Fortnite при известном package ID.

## Безопасные ограничения
Эта версия не меняет CPU/GPU clocks, thermal limits, ядра, напряжения, не убивает фоновые процессы и не отключает защиту от перегрева. Это намеренно: значения и интерфейсы Realme UI China зависят от сборки, а универсальные команды могут вызвать нестабильность.
Shizuku не гарантирует доступ ко всем OEM-функциям. Вывод thermalservice может быть ограничен прошивкой.

## Технические детали
- minSdk 26, targetSdk 35
- Shizuku API `dev.rikka.shizuku:api:13.1.5`
- Kotlin / Android Gradle Plugin

## Сборка без Android Studio (GitHub Actions)
1. Создай пустой репозиторий на GitHub.
2. Загрузи в него все файлы и папки этого проекта, включая скрытую папку `.github`.
3. Открой вкладку Actions и запусти workflow "Build Android APK" кнопкой Run workflow (или дождись сборки после push).
4. Открой завершённый запуск workflow, найди раздел Artifacts и скачай `GTNeo5-Game-Optimizer-APK`.
5. Распакуй скачанный архив на телефоне и установи `app-debug.apk`.
Это debug APK для личной установки, не подписанный релизный APK для Google Play.
